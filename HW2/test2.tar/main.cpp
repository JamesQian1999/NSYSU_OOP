#include "mytar.h"
using namespace std;

int main(int argc, char **argv)
{
    mytar tar((const char*)(argv[1]));
    tar.start_read();
}