#include "mytar.h"
mytar::mytar(const char *file)
{
    inputStream.open(file, ifstream::in | ifstream::binary);

    if (!inputStream.is_open())
    {
        cout << "mytar: "<<file<<": Cannot open: No such file or directory" << endl;
        exit(0);
    }
}

void mytar::start_read()
{
    int i, size_dec = 0, jump;
    do
    {
        read_header();
        for (i = 0; i < 11; i++)
            size_dec += (int(header[header.size() - 1].filesize[i]) - 48) * pow(8, 10 - i);

        jump = size_dec / 512 + 1;
        size_dec = 0;
        cout << "Name:" << header[header.size() - 1].filename << endl;
    } while (inputStream.seekg(512 * jump, inputStream.cur));
    cout << "done with " << header.size() << " items\n";
    return;
}

void mytar::read_header()
{
    struct TarHeader tempHeader;
    inputStream.read(tempHeader.filename, 100);
    inputStream.read(tempHeader.filemode, 8);
    inputStream.read(tempHeader.userid, 8);
    inputStream.read(tempHeader.groupid, 8);
    inputStream.read(tempHeader.filesize, 12);
    inputStream.read(tempHeader.mtime, 12);
    inputStream.read(tempHeader.checksum, 8);
    inputStream.read(&tempHeader.type, 1);
    inputStream.read(tempHeader.lname, 100);
    inputStream.read(tempHeader.USTAR_id, 6);
    inputStream.read(tempHeader.USTAR_ver, 2);
    inputStream.read(tempHeader.username, 32);
    inputStream.read(tempHeader.groupname, 32);
    inputStream.read(tempHeader.devmajor, 8);
    inputStream.read(tempHeader.devminor, 8);
    inputStream.read(tempHeader.prefix, 155);
    inputStream.read(tempHeader.pad, 12);

    header.push_back(tempHeader);
}
